"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[103],{

/***/ 10103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("{\n    \"overrides\": [\n        {\n            \"files\": \"*.sol\",\n            \"options\": {\n                \"printWidth\": 80,\n                \"tabWidth\": 4,\n                \"useTabs\": false,\n                \"singleQuote\": false,\n                \"bracketSpacing\": false\n            }\n        },\n        {\n            \"files\": \"*.yml\",\n            \"options\": {}\n        },\n        {\n            \"files\": \"*.yaml\",\n            \"options\": {}\n        },\n        {\n            \"files\": \"*.toml\",\n            \"options\": {}\n        },\n        {\n            \"files\": \"*.json\",\n            \"options\": {}\n        },\n        {\n            \"files\": \"*.js\",\n            \"options\": {}\n        },\n        {\n            \"files\": \"*.ts\",\n            \"options\": {}\n        }\n    ]\n}\n");

/***/ })

}]);
//# sourceMappingURL=103.plugin-etherscan.1701961435668.js.map